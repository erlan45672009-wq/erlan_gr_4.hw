# ⚙️ Установка Dart SDK на Windows

Следуйте этим шагам, чтобы установить **Dart SDK** и настроить работу в **Visual Studio Code**:

---

## 🪟 1. Откройте PowerShell от имени администратора
Нажмите **Пуск → Введите “PowerShell” → Правый клик → “Запуск от имени администратора”**.

---

## 📥 2. Установите Chocolatey
Вставьте и выполните следующую команду (одной строкой):

```powershell
Set-ExecutionPolicy Bypass -Scope Process -Force; `
[System.Net.ServicePointManager]::SecurityProtocol = `
[System.Net.ServicePointManager]::SecurityProtocol -bor 3072; `
iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
```

💡 *Chocolatey — это менеджер пакетов для Windows, упрощающий установку программ из командной строки.*

---

## 🍫 3. Установите Dart SDK
После завершения установки Chocolatey выполните:

```powershell
choco install dart-sdk -y
```

---

## 🔍 4. Проверьте установку Dart
Проверьте, что Dart установлен корректно:

```powershell
dart --version
```

✅ В терминале должна появиться информация о версии, например:
```
Dart SDK version: 3.4.0 (stable)
```

---

## 💻 5. Настройте VS Code

1. Откройте **Visual Studio Code**  
2. Перейдите в **Extensions (Ctrl+Shift+X)**  
3. Установите расширения:
   - **Dart**
   - *(по желанию)* **Flutter**

4. Перезапустите VS Code

---

## 🚀 6. Создайте первый проект

1. Нажмите **Ctrl+Shift+P**  
2. Выберите **Dart: New Project → Console Application**  
3. Укажите папку и имя проекта  
4. Готово 🎉 — проект создан!

---

💡 **Совет:**  
Чтобы сразу запустить проект, откройте встроенный терминал VS Code и выполните:
```bash
dart run
```

---

© 2025 — Инструкция по установке Dart SDK
