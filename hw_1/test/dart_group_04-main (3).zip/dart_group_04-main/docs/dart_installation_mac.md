# 🍏 Установка Dart SDK на macOS

Ниже — быстрый и надёжный способ поставить **Dart SDK** на macOS и начать работать в **VS Code**.

---

## ✅ Вариант 1. Через Homebrew (рекомендуется)

1) Установите Homebrew (если ещё нет):
```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```
После установки выполните подсказанные команды `eval` для добавления Homebrew в `PATH` (обычно это что‑то вроде):
```bash
echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile
eval "$(/opt/homebrew/bin/brew shellenv)"
```

2) Установите Dart SDK:
```bash
brew tap dart-lang/dart
brew install dart
```

3) Проверьте, что Dart установлен:
```bash
dart --version
```

> Обновление позже: `brew upgrade dart`  
> Информация о пакете: `brew info dart`

---

## 🧰 Вариант 2. Вместе с Flutter (Dart входит в состав)
Если вы планируете Flutter, можно поставить Flutter — Dart идёт в комплекте.
```bash
brew install --cask flutter
flutter --version
```
Проверьте Dart, идущий с Flutter:
```bash
flutter doctor
dart --version
```

---

## 💻 Настройка VS Code
1) Откройте **Visual Studio Code**  
2) Установите расширения (**Extensions / Ctrl+Shift+X**):
   - **Dart**
   - *(по желанию)* **Flutter**
3) Перезапустите VS Code (или перезагрузите окно: **Cmd+Shift+P → Reload Window**).

---

## 🚀 Создание и запуск проекта на Dart
Создать консольный проект (любой каталог):
```bash
dart create -t console my_app
cd my_app
dart run
```

Структура:
```
my_app/
├─ bin/            # Точка входа
├─ lib/            # Модули и логика
├─ pubspec.yaml    # Зависимости
└─ test/           # Тесты (опционально)
```

---

## 🧭 Полезные команды
```bash
dart pub get                  # Установить зависимости
dart pub add http             # Добавить пакет
dart format .                 # Форматирование
dart analyze                  # Анализ кода
dart test                     # Запуск тестов
dart compile exe bin/main.dart  # Сборка исполняемого файла
```

---

## 🛠️ Частые вопросы
- **Команда `dart` не находится?**  
  Убедитесь, что `brew` добавлен в `PATH` и перезапустите терминал. Для Apple Silicon:
  ```bash
  echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile
  eval "$(/opt/homebrew/bin/brew shellenv)"
  ```
- **Несколько версий Dart (из Flutter и из Brew)?**  
  Проверьте, что используется нужный бинарь:
  ```bash
  which dart
  ```
  Приоритет можно изменить корректировкой порядка путей в `PATH`.

---

© 2025 — Инструкция по установке Dart SDK на macOS
